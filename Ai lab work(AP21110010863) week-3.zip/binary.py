l=int(input("Enter the height of a Binary Tree:"))
tr=[[] for _ in range(l)]
lft_tree=[[] for i in range(l-1)]
rht_tree=[[] for j in range(l-1)]
chk=True
for k in range(l):
    total_no_of_nodes=pow(2,k)
    for p in range(total_no_of_nodes):
        node=int(input("Enter the number of nodes data in level {} :".format(k+1)))
        tr[k].append(node)
        if k>0:
            if p<total_no_of_nodes//2:
                lft_tree[k-1].append(node)
            else:
                rht_tree[k-1].append(node)
    if lft_tree[k-1]!=rht_tree[k-1]:
        chk=False
print(tr)
print(lft_tree)
print(rht_tree)
print(chk)