import numpy as np  
print("Enter the matrix actions to be performed: ",end="\n")
matrix = [[int(input()) for c in range (3)] for r in range(3)]
print("Enter the matrix the final matrix: ",end="\n")
matrix2= [[int(input()) for c in range (3)] for r in range(3)]
def create(matrix,c,w,r,f):
    def huristic(matrix,c,d):
        count=0
        for x in range(3):
            for y in range(3):
                if(matrix[x][y]!=matrix2[x][y]):
                    count+=1
        print("the huristic value :",count,end=" \n")            
    def find():
        for x in range(3):
            for y in range(3):
                if(matrix[x][y]==0):
                    c=x
                    w=y
        return c,w
    def left(matrix,c,w):
            if w > 0:
                print("depth level",r)
                print("Action performed: ","left")
                matrix1=np.copy(matrix)
                temp1=matrix1[c][w-1]
                matrix1[c][w-1]=matrix1[c][w]
                matrix1[c][w]=temp1
                c,w=find()
                print(matrix1,end="\n")
                huristic(matrix1,c,w)
                create(matrix1,c,w,r+1,f)
    def right(matrix,c,w):
            if w < 2 :  
                print("depth level",r)
                print("Action performed: ","right")
                matrix1=np.copy(matrix)  
                temp1=matrix1[c][w+1]
                matrix1[c][w+1]=matrix1[c][w]
                matrix1[c][w]=temp1
                c,w=find()
                print(matrix1,end="\n")
                huristic(matrix1,c,w)
                create(matrix1,c,w,r+1,f)
    def up(matrix,c,w):
            if c > 0:
                print("depth level",r)
                print("Action performed: ",'up')
                matrix1=np.copy(matrix)
                temp1=matrix[c-1][w]
                matrix1[c-1][w]=matrix[c][w]
                matrix1[c][w]=temp1
                c,w=find()
                print(matrix1,end="\n")
                huristic(matrix1,c,w)
                create(matrix1,c,w,r+1,f)
    def down(matrix,c,w):
            if c < 2:  
                print("depth level",r)
                print("Action performed: ",'down')
                matrix1=np.copy(matrix)  
                temp1=matrix1[c+1][w]
                matrix1[c+1][w]=matrix1[c][w]
                matrix1[c][w]=temp1
                c,w=find()
                print(matrix1,end="\n")
                huristic(matrix1,c,w)
                create(matrix1,c,w,r+1,f)
    if r>f:
        return 0
    c,w=find()
    left(matrix,c,w)
    right(matrix,c,w)
    up(matrix,c,w)
    down(matrix,c,w)
print(matrix,end="\n")    
c=0
w=0
r=0
print("Enter the max depth for the tree: ",end="\n")
f=int(input())
create(np.array(matrix),c,w,r+1,f)