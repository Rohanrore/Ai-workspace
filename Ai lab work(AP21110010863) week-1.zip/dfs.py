graph={
    '1':['2','3'],
    '2':['4','5'],
    '3':['6'],
    '4':['7'],
    '5':['8'],
    '6':[],
    '7':[],
    '8':[],
}
visited_vertex=set()
def dfs(visited_vertex,graph,node):
    if node not in visited_vertex:
        print(node)
        for neighbour in graph[node]:
            dfs(visited_vertex,graph,neighbour)
starting_vertex='1'
print('This is the following result of dfs:')
dfs(visited_vertex,graph,starting_vertex)