graph={
    '1':['2','3'],
    '2':['4','5'],
    '3':['6','7'],
    '4':['8'],
    '5':[],
    '6':['9','10'],
    '7':[],
    '8':[],
    '9':[],
    '10':[],
}
visited_vertex=[]
queue=[]
def bfs(visited_vertex,graph,node):
    visited_vertex.append(node)
    queue.append(node)
    while queue:
        d=queue.pop(0)
        print(d,end=" ")
        for neighbour in graph[d]:
            if neighbour not in visited_vertex:
                visited_vertex.append(neighbour)
                queue.append(neighbour)
Starting_node='1'
print('this is the following result of bfs:')
bfs(visited_vertex,graph,Starting_node)