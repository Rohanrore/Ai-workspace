graph={
    '1':['2','3'],
    '2':['4','5'],
    '3':['6'],
    '4':['7'],
    '5':['8'],
    '6':[],
    '7':[],
    '8':[],
}
def topological_sort(graph):
    def dfs(vertex):
        visited.add(vertex)
        for neighbor in graph[vertex]:
            if neighbor not in visited:
                dfs(neighbor)
        result.append(vertex)
    visited = set()
    result = []
    for vertex in graph:
        if vertex not in visited:
            dfs(vertex)
    return result[::-1]
topological_order = topological_sort(graph)
print("Topological sorting for the given elements:", topological_order)